boiler-plate-ko is being sponsored by the following tool <br />
Please help to support us by taking a look and signing up to a free trial
<a href="https://tracking.gitads.io/?repo=boiler-plate-ko"><img src="https://images.gitads.io/boiler-plate-ko" alt="GitAds"/></a> 


안녕하세요^^ 

이 어플리케이션을 사용하기 위해선 

1. dev.js file을 config 폴더 안에 생성해주세요.  
2. mongoDB 정보를 dev.js file안에다가 넣어주세요. 
3. " npm install "을 root directory에서 입력해주세요.  (백엔드 종속성 다운받기) 
4. " npm install "을 client directory에서 입력해주세요.  (프론트엔드 종속성 다운받기) 

이 강의는 아래 보이는 링크를 통해서 보실수 있습니다. 

https://www.youtube.com/watch?v=fgoMqmNKE18&list=PL9a7QRYt5fqkZC9jc7jntD1WuAogjo_9T

감사합니다 ^^.
